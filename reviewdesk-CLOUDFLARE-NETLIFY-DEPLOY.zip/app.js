const $=id=>document.getElementById(id);
let current=null,busy=false,timer,redirectURL='',copyRetry=null,slug='',business=null,seenReviewIds=[];

const pathSlug=()=>{
  const path=decodeURIComponent(location.pathname||'/');
  const parts=path.split('/').filter(Boolean);
  if(!parts.length || /(^|\/)index\.html?$/i.test(path)) return '';
  if(parts.length===1 && /^(index|reviewapp)$/i.test(parts[0])) return '';
  return parts[0]||'';
};
const normalizeSlug=value=>String(value||'').trim().toLowerCase().replace(/^\/+|\/+$/g,'').split('/')[0];
function status(text=''){const el=$('status');if(el)el.textContent=text}
function controls(){
  $('next').disabled=busy||!current;
  $('use').disabled=busy||!current&&!redirectURL;
}
function clearCurrent(){clearTimeout(timer);current=null;$('review').value='';redirectURL='';copyRetry=null;controls();}
function arm(){
  clearTimeout(timer);
  if(current?.expires) timer=setTimeout(()=>{
    clearCurrent();
    status('This draft expired. Loading the next review…');
    loadNextReview(null);
  },Math.max(0,current.expires-Date.now()-1000));
}
async function copy(text){
  try{await navigator.clipboard.writeText(text);return true}
  catch{
    const area=document.createElement('textarea');area.value=text;area.className='clipboard-helper';area.setAttribute('aria-hidden','true');document.body.append(area);area.select();
    try{return document.execCommand('copy')}catch{return false}finally{area.remove()}
  }
}
function escapeHtml(value){return String(value||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function renderReviewCard(text=''){
  const box=$('reviewPool');if(!box)return;
  $('remainingCount').hidden=true;
  $('poolCount').textContent=current?'READY':'NEXT';
  if(!text){
    box.innerHTML='<div class="pool-empty"><div class="empty-icon">→</div><strong>Loading next review…</strong><p>Your next unused review will appear here.</p></div>';
    return;
  }
  box.innerHTML=`<article class="review-option selected next-review-card">
    <div class="review-option-top"><span class="review-number">NEXT REVIEW</span><span class="review-status">Unused</span></div>
    <p>${escapeHtml(text)}</p>
    <div class="next-review-hint">Edit the review below if needed, then continue to Google. Use <strong>Next Review</strong> whenever you want to skip to the next unused draft.</div>
  </article>`;
}

async function loadNextReview(previousLease=null, resetSeen=false){
  if(busy)return;
  if(resetSeen) seenReviewIds=[];
  busy=true;controls();renderReviewCard('');status('Loading next review…');
  try{
    // The database decides what the next unused review is. No client-side
    // review list or artificial 2-item limit is used here.
    const d=await ReviewDB.rpc('rd_mb_next_review',{p_slug:slug,p_previous:previousLease||null,p_exclude_ids:seenReviewIds});
    if(!d?.review){
      if(seenReviewIds.length){
        seenReviewIds=[];
        status('Starting the review pool again…');
        const restart=await ReviewDB.rpc('rd_mb_next_review',{p_slug:slug,p_previous:null,p_exclude_ids:[]});
        if(restart?.review){
          current={id:Number(restart.review.id),text:restart.review.text,lease:restart.review.lease,expires:restart.review.expires};
          seenReviewIds.push(current.id);
          $('review').value=current.text;
          redirectURL='';copyRetry=null;arm();renderReviewCard(current.text);
          status('Edit the review to match your real experience, then continue to Google.');
          return;
        }
      }
      clearCurrent();
      renderReviewCard('');
      $('poolCount').textContent='DONE';
      status('No unused reviews are available right now.');
      return;
    }
    current={id:Number(d.review.id),text:d.review.text,lease:d.review.lease,expires:d.review.expires};
    if(Number.isFinite(current.id) && !seenReviewIds.includes(current.id)) seenReviewIds.push(current.id);
    $('review').value=current.text;
    redirectURL='';copyRetry=null;arm();renderReviewCard(current.text);
    status('Edit the review to match your real experience, then continue to Google.');
  }catch(e){
    clearCurrent();
    renderReviewCard('');
    status(e.message||'Unable to load the next review.');
  }finally{busy=false;controls()}
}

$('next').onclick=async()=>{
  if(!current||busy)return;
  await loadNextReview(current.lease);
};

$('use').onclick=async()=>{
  if(busy)return;
  if(redirectURL){
    busy=true;controls();
    try{
      if(copyRetry&&!await copy(copyRetry)){status('Copy blocked. Allow clipboard access and tap again.');return}
      window.location.assign(redirectURL);
    }finally{busy=false;controls()}
    return;
  }
  if(!current){status('No review is selected.');return}
  const text=$('review').value.trim(),lease=current.lease;
  if(!text){status('Enter your review first.');return}
  busy=true;controls();status('Preparing Google review…');
  try{
    const d=await ReviewDB.rpc('rd_mb_use',{p_slug:slug,p_token:lease});
    redirectURL=d.url;copyRetry=text;
    if(await copy(text)){copyRetry=null;status('Copied. Opening Google…');window.location.assign(d.url)}
    else status('Copy blocked. Allow clipboard access, then tap Continue to Google again.');
  }catch(e){
    status((e.message||'Unable to use this draft.')+' Loading the next review…');
    clearCurrent();
    await loadNextReview(null);
  }finally{busy=false;controls()}
};

setInterval(async()=>{
  if(!current||busy||document.hidden)return;
  const lease=current.lease;
  try{
    const d=await ReviewDB.rpc('rd_mb_renew',{p_slug:slug,p_token:lease});
    if(current?.lease===lease){current.expires=d.expires;arm()}
  }catch{
    clearCurrent();status('This draft expired. Loading the next review…');loadNextReview(null);
  }
},30000);

document.addEventListener('visibilitychange',async()=>{if(document.hidden){$('review').hidden=true;return}$('review').hidden=false;const lease=current?.lease;if(!lease)return;try{const d=await ReviewDB.rpc('rd_mb_renew',{p_slug:slug,p_token:lease});if(current?.lease===lease){current.expires=d.expires;arm()}}catch{clearCurrent();status('This draft expired. Loading the next review…');loadNextReview(null)}});
function show(mode){$('landing').hidden=mode!=='landing';$('reviewApp').hidden=mode!=='review';$('notFound').hidden=mode!=='notFound';}
(async()=>{
  try{ReviewDB.config();}catch(e){$('notFoundText').textContent=e.message;show('notFound');return}
  slug=normalizeSlug(pathSlug());
  if(!slug){show('landing');return}
  try{
    const d=await ReviewDB.rpc('rd_mb_public_business',{p_slug:slug});
    if(!d){$('notFoundText').textContent=`No business is registered at /${slug}.`;show('notFound');return}
    business=d;document.title=d.name+' — Reviews';$('businessName').textContent=d.name;$('businessHint').textContent='Choose a genuine review draft, edit it to match your real experience, then continue to Google.';show('review');await loadNextReview(null);
  }catch(e){$('notFoundText').textContent=e.message||'This review page is unavailable.';show('notFound')}
})();

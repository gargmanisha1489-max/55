// Public Supabase browser configuration. Never use a secret key.
window.REVIEW_CONFIG = {
  "url": "https://sppqjajeiiwtsrrpogkb.supabase.co",
  "key": "sb_publishable_Q03frfEzuyIsuvoxoWShAA_NaFKI-ds"
};

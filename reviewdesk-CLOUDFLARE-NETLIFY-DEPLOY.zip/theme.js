const buttons=[document.getElementById('theme'),document.getElementById('themeLanding'),document.getElementById('theme404')].filter(Boolean);
function setCustomerTheme(mode){document.documentElement.dataset.theme=mode;for(const button of buttons){button.textContent=mode==='light'?'☾ Dark':'☀ Light';button.setAttribute('aria-label',`Switch to ${mode==='light'?'dark':'light'} theme`);};localStorage.setItem('review-customer-theme',mode)}
setCustomerTheme(localStorage.getItem('review-customer-theme')||'light');
buttons.forEach(button=>button.onclick=()=>setCustomerTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));
